#include<stdio.h>
#define size 50
#define arraySize 100
int getLowerBound();
int getUpperBound();
int getUniqueDigit(int);
int compareTwoDigits(int);
int compareThreeDigits(int);
int compareFourDigits(int);

int main(){
    int lower, upper, i, j, k, originalArray[arraySize],numberOfElement = 0,uniqueArray[arraySize],numberOfUniqueElement = 0;
    do{
        lower = getLowerBound();
        upper = getUpperBound();
        if(lower > upper){
            printf("\tInput Error! Be sure A <= B");
        }
    }while(lower > upper);


for( i = lower, j = 0; i <= upper; i++, j++){
    originalArray[j] = i;
    numberOfElement++;
}


for( j = 0; j < numberOfElement; j++){    
    int uniqueNum = getUniqueDigit(originalArray[j]);
    if(uniqueNum != 0){
        uniqueArray[numberOfUniqueElement] = uniqueNum;
        numberOfUniqueElement++;
    }
}

for( k = 0; k < numberOfUniqueElement; k++){
    printf("\t%d\n", uniqueArray[k]);
}
    printf("\t%d\n", numberOfUniqueElement);
    return 0;
}

int getLowerBound(){
    char inBuf[size];
    int lower;
    do{
        printf("\tPlease enter the lower bound A [1-5000]: \n");
        fgets(inBuf, size, stdin);
        sscanf(inBuf, "%d", &lower);
        if(lower < 1 || lower > 5000){
            printf("\tInput Error! A must be in the range [1-5000]:\n");
        }
    }while(lower < 1 || lower > 5000);
    return lower;
}

int getUpperBound(){
    char inBuf[size];
    int upper;
    do{
        printf("\tPlease enter the upper bound B [1-5000]: \n");
        fgets(inBuf, size, stdin);
        sscanf(inBuf, "%d", &upper);
        if(upper < 1 || upper > 5000){
            printf("\tInput Error! B must be in the range [1-5000]:\n");
        }
    }while(upper < 1 || upper > 5000);
    return upper;
}

int getUniqueDigit(int num){
   if((num - 100) < 0){
     /*
     two digit
     */
    int myTwoNumber = compareTwoDigits(num);
    return myTwoNumber;
   }
   else if((num - 1000) < 0){
     /*
     three digit
     */
    int myThreeNumber = compareThreeDigits(num);
    return myThreeNumber;
   }
   else{
     /*
     four digit
     */
    int myFourNumber = compareFourDigits(num);
    return myFourNumber;
   }

    return 0;
}

int compareTwoDigits(int num){
  int tens = num / 10;
  int ones = num % 10;
  if(tens != ones){
    return num;
  } 
  else{
    return 0;
  }
}

int compareThreeDigits(int num){
  int hundreds = num / 100;
  int newTwoNum = num - hundreds * 100;
  int tens = newTwoNum / 10;
  int ones = newTwoNum % 10;
  if(hundreds != tens && hundreds != ones && tens != ones){
    return num;
  }
  else{
    return 0;
  }
}

int compareFourDigits(int num){
  int thousands = num / 1000;
  int newThreeNum = num - thousands * 1000;
  int hundreds = newThreeNum / 100;
  int newTwoNum = newThreeNum - hundreds * 100;
  int tens = newTwoNum /10;
  int ones = newTwoNum % 10;
  if(thousands != hundreds && thousands != tens && thousands != ones && hundreds != tens && hundreds != ones && tens != ones){
    return num;
  }
  else{
    return 0;
  }
}



